import discord
from discord.ext import commands, tasks
import json
import asyncio
import time
import os
import random
import shutil

# Load bot configuration
with open('bot.json', 'r') as f:
    config = json.load(f)

# Helper function to check if user is authorized
def is_authorized_user(user_id):
    """Check if user ID is in authorized users list"""
    return str(user_id) in config.get('authorized_users', [])

# Load user settings (create if doesn't exist)
def load_user_settings():
    try:
        with open('user_settings.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_user_settings(settings):
    with open('user_settings.json', 'w') as f:
        json.dump(settings, f, indent=2)

# Load cooldowns (create if doesn't exist)
def load_cooldowns():
    try:
        with open('cooldowns.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_cooldowns(cooldowns):
    with open('cooldowns.json', 'w') as f:
        json.dump(cooldowns, f, indent=2)

# Load whitelist (create if doesn't exist)
def load_whitelist():
    try:
        with open('whitelisted.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_whitelist(whitelist):
    with open('whitelisted.json', 'w') as f:
        json.dump(whitelist, f, indent=2)

# Parse duration string to seconds
def parse_duration(duration_str):
    import re
    
    if duration_str.lower() == "lifetime":
        return float('inf')
    
    # Pattern to match number followed by time unit
    pattern = r'^(\d+)([smhdwy])$'
    match = re.match(pattern, duration_str.lower())
    
    if not match:
        return None
    
    amount, unit = int(match.group(1)), match.group(2)
    
    multipliers = {
        's': 1,           # seconds
        'm': 60,          # minutes
        'h': 60 * 60,     # hours
        'd': 60 * 60 * 24,  # days
        'w': 60 * 60 * 24 * 7,  # weeks
        'y': 60 * 60 * 24 * 365  # years (approximate)
    }
    
    return amount * multipliers.get(unit, 0)

user_settings = load_user_settings()
user_cooldowns = load_cooldowns()
whitelisted_users = load_whitelist()

# Bot setup with intents
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents, activity=discord.Game(name="MADE BY MUMYA(@qrd9)"))

async def check_expired_whitelists():
    """Background task to check and remove expired whitelist users"""
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            current_time = int(time.time())
            expired_users = []
            
            for user_id, whitelist_data in whitelisted_users.items():
                end_time = whitelist_data.get('end_time', 0)
                if end_time != float('inf') and current_time >= end_time:
                    expired_users.append(user_id)
            
            # Remove expired users and their premium roles
            for user_id in expired_users:
                del whitelisted_users[user_id]
                print(f"Removed expired whitelist for user {user_id}")
                
                # Remove premium role from all guilds
                for guild in bot.guilds:
                    member = guild.get_member(int(user_id))
                    if member:
                        premium_role = guild.get_role(1374676222935830549)
                        if premium_role and premium_role in member.roles:
                            try:
                                await member.remove_roles(premium_role, reason="Whitelist expired")
                                print(f"Removed premium role from {member.display_name} in {guild.name}")
                            except Exception as e:
                                print(f"Failed to remove premium role: {e}")
            
            if expired_users:
                save_whitelist(whitelisted_users)
            
        except Exception as e:
            print(f"Error in whitelist check: {e}")
        
        await asyncio.sleep(60)  # Check every minute

async def check_cooldowns():
    """Background task to check and notify users when cooldowns expire"""
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            current_time = time.time()
            cooldowns = load_cooldowns()
            settings = load_user_settings()
            
            # Check for expired cooldowns
            for user_id, user_cooldowns in cooldowns.items():
                user_settings = settings.get(user_id, {})
                ping_notify = user_settings.get('ping_notify', False)
                
                if ping_notify:
                    # Check if user is premium
                    whitelisted = load_whitelist()
                    is_premium = user_id in whitelisted
                    
                    if is_premium:
                        expired_services = []
                        for service, cooldown_time in user_cooldowns.items():
                            if current_time >= cooldown_time:
                                expired_services.append(service)
                        
                        # Send notifications for expired cooldowns
                        for service in expired_services:
                            await send_cooldown_notification(user_id, service)
                            # Remove expired cooldown
                            del user_cooldowns[service]
                        
                        # Save updated cooldowns if changes were made
                        if expired_services:
                            save_cooldowns(cooldowns)
            
        except Exception as e:
            print(f"Error in cooldown check: {e}")
        
        # Check every 30 seconds
        await asyncio.sleep(30)

async def send_cooldown_notification(user_id, service):
    """Send DM notification when cooldown expires"""
    try:
        user = bot.get_user(int(user_id))
        if not user:
            return
        
        # Create embed for notification
        embed = discord.Embed(
            title="🔔 Cooldown Expired!",
            description=f"Your cooldown for **{service.upper()}** has ended!",
            color=int(config.get('embed_color', '0x242628'), 16)
        )
        
        embed.add_field(
            name="💎 Ready to Generate",
            value=f"You can now generate **{service.upper()}** accounts again!",
            inline=False
        )
        
        embed.set_image(url=config.get('embed_image', ''))
        embed.set_footer(text="Sky Gen - Premium Notification")
        embed.timestamp = discord.utils.utcnow()
        
        # Create view with generate button
        view = CooldownNotificationView()
        
        try:
            # Try to send DM first
            await user.send(embed=embed, view=view)
        except discord.Forbidden:
            # If DM fails, send to specific channel and ping user
            channel = bot.get_channel(1368173902844395683)
            if channel and hasattr(channel, 'send'):
                message = await channel.send(f"<@{user_id}>", embed=embed, view=view)
                # Delete the ping message after 1 second
                await asyncio.sleep(1)
                try:
                    await message.edit(content="", embed=embed, view=view)
                except:
                    pass
    except Exception as e:
        print(f"Error sending cooldown notification: {e}")

class CooldownNotificationView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(
        label="Generate",
        style=discord.ButtonStyle.primary,
        emoji="💎"
    )
    async def generate_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Button to redirect to generation channel"""
        try:
            await interaction.response.send_message(
                "🔗 Click here to access the generation panel: https://discord.com/channels/1367477064952713259/1368173902844395683",
                ephemeral=True
            )
        except Exception as e:
            print(f"Error in generate button: {e}")

@bot.event
async def on_ready():
    """Event triggered when bot is ready"""
    print(f'{bot.user} has connected to Discord!')
    print(f'Bot is in {len(bot.guilds)} guilds')
    
    # Start background tasks
    bot.loop.create_task(check_expired_whitelists())
    bot.loop.create_task(check_cooldowns())
    
    # Sync slash commands
    try:
        synced = await bot.tree.sync()
        print(f'Synced {len(synced)} command(s)')
    except Exception as e:
        print(f'Failed to sync commands: {e}')

@bot.tree.command(name='ping', description='Check the bot\'s response time and connection status')
async def ping(interaction: discord.Interaction):
    """Slash command to check bot latency"""
    
    # Check if user is authorized
    if not is_authorized_user(interaction.user.id):
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True
        )
        return
    
    # Calculate latency
    start_time = time.time()
    
    # Bot latency (WebSocket latency)
    ws_latency = round(bot.latency * 1000)
    
    # Create embed
    embed = discord.Embed(
        title="🏓 Pong!",
        description=f"Bot latency information",
        color=int(config.get('embed_color', '0x242628'), 16)
    )
    
    # Add fields to embed
    embed.add_field(
        name="🌐 WebSocket Latency",
        value=f"`{ws_latency}ms`",
        inline=True
    )
    
    # Calculate API latency after responding
    api_latency = round((time.time() - start_time) * 1000)
    
    embed.add_field(
        name="⚡ API Latency",
        value=f"`{api_latency}ms`",
        inline=True
    )
    
    embed.add_field(
        name="📊 Overall Status",
        value="🟢 Online" if ws_latency < 200 else "🟡 Slow" if ws_latency < 500 else "🔴 Lagging",
        inline=True
    )
    
    # Set embed image
    embed.set_image(url=config.get('embed_image', ''))
    
    # Set footer with timestamp
    embed.set_footer(
        text=f"Requested by {interaction.user.display_name}",
        icon_url=interaction.user.display_avatar.url
    )
    
    embed.timestamp = discord.utils.utcnow()
    
    # Send response with greeting message and embed
    await interaction.response.send_message(
        content=f"👋 Hi {interaction.user.mention}, here the ping:",
        embed=embed
    )

@bot.tree.command(name='setinvites', description='Set the invite count for a specific user (Admin only)')
@discord.app_commands.describe(
    user='Select the user whose invite count you want to set',
    count='Enter the number of invites (example: 10)'
)
async def setinvites(interaction: discord.Interaction, user: discord.Member, count: int):
    """Admin command to set invite count for testing"""
    
    # Check if user is authorized
    if not is_authorized_user(interaction.user.id):
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True
        )
        return
    
    # Check if user has administrator permissions, is server owner, or is authorized
    if not interaction.guild:
        await interaction.response.send_message(
            "❌ This command can only be used in a server.",
            ephemeral=True
        )
        return
    
    member = interaction.guild.get_member(interaction.user.id)
    is_admin = member and member.guild_permissions.administrator
    is_owner = interaction.user.id == interaction.guild.owner_id
    is_authorized = str(interaction.user.id) in config.get('authorized_users', [])
    
    if not (is_admin or is_owner or is_authorized):
        await interaction.response.send_message(
            "❌ You need administrator permissions, be the server owner, or be authorized to use this command.",
            ephemeral=True
        )
        return
    
    user_id = str(user.id)
    if user_id not in user_settings:
        user_settings[user_id] = {}
    
    user_settings[user_id]['invite_count'] = count
    save_user_settings(user_settings)
    
    await interaction.response.send_message(
        f"✅ Set invite count for {user.mention} to {count}",
        ephemeral=True
    )

@bot.tree.command(name='addstock', description='Add accounts to stock inventory (Admin only)')
@discord.app_commands.describe(
    type='Choose account type: "free" or "premium"',
    service='Enter service name (example: netflix, spotify, discord)',
    accounts='Enter accounts separated by new lines (format: email:password)',
    file='Upload a .txt file containing accounts (one per line)'
)
async def addstock(interaction: discord.Interaction, type: str, service: str, accounts: str = None, file: discord.Attachment = None):
    """Admin command to add accounts to stock"""
    
    # Check if user is authorized
    if not is_authorized_user(interaction.user.id):
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True
        )
        return
    
    # Check if user has administrator permissions, is server owner, or is authorized
    if not interaction.guild:
        await interaction.response.send_message(
            "❌ This command can only be used in a server.",
            ephemeral=True
        )
        return
    
    member = interaction.guild.get_member(interaction.user.id)
    is_admin = member and member.guild_permissions.administrator
    is_owner = interaction.user.id == interaction.guild.owner_id
    is_authorized = str(interaction.user.id) in config.get('authorized_users', [])
    
    if not (is_admin or is_owner or is_authorized):
        await interaction.response.send_message(
            "❌ You need administrator permissions, be the server owner, or be authorized to use this command.",
            ephemeral=True
        )
        return
    
    # Validate type
    if type.lower() not in ['free', 'premium']:
        await interaction.response.send_message(
            "❌ Type must be either 'free' or 'premium'.",
            ephemeral=True
        )
        return
    
    # Create directory if it doesn't exist
    stock_dir = f"stocks/{type.lower()}"
    os.makedirs(stock_dir, exist_ok=True)
    
    file_path = f"{stock_dir}/{service.lower()}.txt"
    
    accounts_to_add = []
    
    # Get accounts from text parameter
    if accounts:
        accounts_to_add.extend([acc.strip() for acc in accounts.split('\n') if acc.strip()])
    
    # Get accounts from file attachment
    if file:
        if file.filename.endswith('.txt'):
            try:
                file_content = await file.read()
                file_accounts = file_content.decode('utf-8').split('\n')
                accounts_to_add.extend([acc.strip() for acc in file_accounts if acc.strip()])
            except Exception as e:
                await interaction.response.send_message(
                    "❌ Error reading file. Make sure it's a valid text file.",
                    ephemeral=True
                )
                return
        else:
            await interaction.response.send_message(
                "❌ File must be a .txt file.",
                ephemeral=True
            )
            return
    
    if not accounts_to_add:
        await interaction.response.send_message(
            "❌ No accounts provided. Use either the accounts parameter or upload a .txt file.",
            ephemeral=True
        )
        return
    
    # Add accounts to file
    try:
        with open(file_path, 'a') as f:
            for account in accounts_to_add:
                f.write(account + '\n')
        
        await interaction.response.send_message(
            f"✅ Added {len(accounts_to_add)} accounts to {type.upper()} {service.upper()} stock.",
            ephemeral=True
        )
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error adding accounts to stock.",
            ephemeral=True
        )

@bot.tree.command(name='unstock', description='Delete all accounts from a specific stock (Admin only)')
@discord.app_commands.describe(
    type='Choose account type: "free" or "premium"',
    stockname='Enter the service name to clear (example: netflix, spotify)'
)
async def unstock(interaction: discord.Interaction, type: str, stockname: str):
    """Admin command to delete all accounts from a stock"""
    
    # Check if user is authorized
    if not is_authorized_user(interaction.user.id):
        await interaction.response.send_message(
            "❌ You are not authorized to use this command.",
            ephemeral=True
        )
        return
    
    # Validate type
    if type.lower() not in ['free', 'premium']:
        await interaction.response.send_message(
            "❌ Type must be either 'Free' or 'Premium'.",
            ephemeral=True
        )
        return
    
    # Check if stock file exists
    stock_dir = f"stocks/{type.lower()}"
    file_path = f"{stock_dir}/{stockname.lower()}.txt"
    
    if not os.path.exists(file_path):
        await interaction.response.send_message(
            f"❌ Stock **{stockname.upper()}** does not exist in **{type.upper()}**.",
            ephemeral=True
        )
        return
    
    try:
        # Delete all accounts by clearing the file
        with open(file_path, 'w') as f:
            f.write('')
        
        await interaction.response.send_message(
            f"✅ Successfully deleted all accounts from **{type.upper()} - {stockname.upper()}** stock.",
            ephemeral=True
        )
    except Exception as e:
        await interaction.response.send_message(
            "❌ Error deleting stock accounts.",
            ephemeral=True
        )

@bot.tree.command(name='stock', description='Create or delete a stock category (Admin only)')
@discord.app_commands.describe(
    do='Choose action: "create" to make new stock or "delete" to remove stock',
    type='Choose account type: "free" or "premium"',
    stockname='Enter the service name (example: netflix, spotify, discord)'
)
async def stock(interaction: discord.Interaction, do: str, type: str, stockname: str):
    """Admin command to create or delete a stock"""
    
    # Check if user is authorized
    if not is_authorized_user(interaction.user.id):
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True
        )
        return
    
    # Validate parameters
    if do.lower() not in ['add', 'delete']:
        await interaction.response.send_message(
            "❌ Do must be either 'add' or 'delete'.",
            ephemeral=True
        )
        return
    
    if type.lower() not in ['free', 'premium']:
        await interaction.response.send_message(
            "❌ Type must be either 'Free' or 'Premium'.",
            ephemeral=True
        )
        return
    
    stock_dir = f"stocks/{type.lower()}"
    file_path = f"{stock_dir}/{stockname.lower()}.txt"
    
    if do.lower() == 'add':
        # Create stock
        os.makedirs(stock_dir, exist_ok=True)
        
        if os.path.exists(file_path):
            await interaction.response.send_message(
                f"❌ Stock **{stockname.upper()}** already exists in **{type.upper()}**.",
                ephemeral=True
            )
            return
        
        try:
            # Create empty stock file
            with open(file_path, 'w') as f:
                f.write('')
            
            await interaction.response.send_message(
                f"✅ Successfully created **{type.upper()} - {stockname.upper()}** stock.",
                ephemeral=True
            )
        except Exception as e:
            await interaction.response.send_message(
                "❌ Error creating stock.",
                ephemeral=True
            )
    
    elif do.lower() == 'delete':
        # Delete stock
        if not os.path.exists(file_path):
            await interaction.response.send_message(
                f"❌ Stock **{stockname.upper()}** does not exist in **{type.upper()}**.",
                ephemeral=True
            )
            return
        
        try:
            os.remove(file_path)
            await interaction.response.send_message(
                f"✅ Successfully deleted **{type.upper()} - {stockname.upper()}** stock.",
                ephemeral=True
            )
        except Exception as e:
            await interaction.response.send_message(
                "❌ Error deleting stock.",
                ephemeral=True
            )

@bot.tree.command(name='whitelist', description='Grant temporary premium access to a user (Admin only)')
@discord.app_commands.describe(
    user='Select the user to grant premium access to',
    duration='Enter duration: "lifetime" or time format like "1d", "5h", "30m" (d=days, h=hours, m=minutes)'
)
async def whitelist(interaction: discord.Interaction, user: discord.Member, duration: str):
    """Admin command to grant temporary premium access"""
    
    # Check if user is authorized
    if not is_authorized_user(interaction.user.id):
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True
        )
        return
    
    # Parse duration
    duration_seconds = parse_duration(duration)
    if duration_seconds is None:
        await interaction.response.send_message(
            "❌ Invalid duration format. Use formats like: 1s, 2m, 3h, 4d, 5w, 6y, or 'lifetime'",
            ephemeral=True
        )
        return
    
    # Calculate end time
    current_time = int(time.time())
    if duration_seconds == float('inf'):
        end_time = float('inf')
        duration_text = "lifetime"
    else:
        end_time = current_time + duration_seconds
        duration_text = f"<t:{int(end_time)}:R>"
    
    # Add to whitelist
    user_id = str(user.id)
    whitelisted_users[user_id] = {
        'end_time': end_time,
        'granted_by': str(interaction.user.id),
        'granted_at': current_time
    }
    save_whitelist(whitelisted_users)
    
    # Give premium role
    premium_role_id = 1374676222935830549
    if interaction.guild:
        premium_role = interaction.guild.get_role(premium_role_id)
        if premium_role:
            try:
                await user.add_roles(premium_role, reason=f"Whitelisted by {interaction.user}")
                print(f"Added premium role to {user.display_name}")
            except Exception as e:
                print(f"Failed to add premium role: {e}")
    
    await interaction.response.send_message(
        f"✅ {user.mention} has been whitelisted for {duration_text}",
        ephemeral=True
    )

@bot.tree.command(name='panel', description='Access the main generation panel for all services')
async def panel(interaction: discord.Interaction):
    """Slash command for the Sea Gen panel - available to everyone"""
    
    # Check if user is authorized
    if not is_authorized_user(interaction.user.id):
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True
        )
        return
    
    # Create the admin panel embed
    embed = discord.Embed(
        title="🔵 Sea Gen Generation Panel",
        description="Generate **any account** with various services. Customize your experience with **user settings**.",
        color=int(config.get('embed_color', '0x242628'), 16)
    )
    
    # Add fields to embed
    embed.add_field(
        name="👑 Premium Advantages",
        value="Premium users enjoy lower **cooldowns**, access to exclusive **services**, priority support, and exclusive **features**.",
        inline=False
    )
    
    embed.add_field(
        name="⌛ Cooldowns",
        value="Each service has a specific **cooldown** to ensure fair usage. Premium users **benefit** from **reduced** cooldown times.",
        inline=False
    )
    
    embed.add_field(
        name="⚙️ User Settings",
        value="You can use & access settings to toggle **DM Generation** when you enable it, it gonna send accounts in your dms!",
        inline=False
    )
    
    embed.add_field(
        name="🔵 Sea Gen",
        value="Want to sail because of happiness of the accounts u got from **Sea Gen**?",
        inline=False
    )
    
    # Set embed image
    embed.set_image(url=config.get('embed_image', ''))
    
    # Set footer with timestamp
    embed.set_footer(
        text=f"Admin panel accessed by {interaction.user.display_name}",
        icon_url=interaction.user.display_avatar.url
    )
    
    embed.timestamp = discord.utils.utcnow()
    
    # Create view with dropdown and settings button
    view = PanelView()
    
    # Send response with embed and view
    await interaction.response.send_message(embed=embed, view=view)

class PanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # Never timeout
        self.selected_service = None
        self.add_item(ServiceDropdown())
        self.add_item(GenerateButton())
        self.add_item(SettingsButton())
        self.add_item(StocksButton())
        self.add_item(PremiumButton())
        self.add_item(HelpButton())

class ServiceDropdownView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # Never timeout
        self.add_item(ServiceDropdown())

class GenerateButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            label="Generate",
            emoji="🔥",
            style=discord.ButtonStyle.success
        )
    
    async def callback(self, interaction: discord.Interaction):
        # Check if a service was selected
        if not hasattr(self.view, 'selected_service') or not self.view.selected_service:
            await interaction.response.send_message(
                "❌ Please choose a stock from the dropdown first!",
                ephemeral=True
            )
            return
        
        # Parse the selected service
        service_type, service_name = self.view.selected_service.split('_', 1)
        file_path = f"stocks/{service_type}/{service_name}.txt"
        
        # Get user settings for DM generation
        user_id = str(interaction.user.id)
        dm_enabled = user_settings.get(user_id, {}).get('dm_generation', False)
        
        # Check cooldown
        current_time = int(time.time())
        if user_id in user_cooldowns:
            cooldown_end = user_cooldowns[user_id].get('end_time', 0)
            if current_time < cooldown_end:
                await interaction.response.send_message(
                    f"You're already sailing in sea, wait until you dock <t:{cooldown_end}:D>",
                    ephemeral=True
                )
                return
        
        # Check role/invite requirements - ALWAYS CHECK FRESH EVERY TIME
        if service_type == "premium":
            # Check for premium role or whitelist FRESH EVERY TIME
            premium_role_id = 1374676222935830549
            has_premium_role = False
            is_whitelisted = False
            
            # FRESH CHECK: Premium role
            if interaction.guild:
                try:
                    # Refresh member data
                    member = await interaction.guild.fetch_member(interaction.user.id)
                    if member:
                        premium_role = interaction.guild.get_role(premium_role_id)
                        if premium_role and premium_role in member.roles:
                            has_premium_role = True
                except:
                    member = interaction.guild.get_member(interaction.user.id)
                    if member:
                        premium_role = interaction.guild.get_role(premium_role_id)
                        if premium_role and premium_role in member.roles:
                            has_premium_role = True
            
            # FRESH CHECK: Whitelist
            if user_id in whitelisted_users:
                whitelist_data = whitelisted_users[user_id]
                end_time = whitelist_data.get('end_time', 0)
                if end_time == float('inf') or current_time < end_time:
                    is_whitelisted = True
                else:
                    # Remove expired whitelist entry
                    del whitelisted_users[user_id]
                    save_whitelist(whitelisted_users)
                    # Remove premium role if user has it
                    if interaction.guild and member:
                        premium_role = interaction.guild.get_role(premium_role_id)
                        if premium_role and premium_role in member.roles:
                            try:
                                await member.remove_roles(premium_role, reason="Whitelist expired")
                            except Exception as e:
                                print(f"Failed to remove premium role: {e}")
            
            if not has_premium_role and not is_whitelisted:
                await interaction.response.send_message(
                    "❌ You need premium access to generate premium accounts!",
                    ephemeral=True
                )
                return
        else:
            # Free service - check invite requirement
            invite_count = user_settings.get(user_id, {}).get('invite_count', 0)
            if invite_count < 2:
                await interaction.response.send_message(
                    "❌ You need at least 2 invites to generate free accounts!",
                    ephemeral=True
                )
                return
        
        # Try to read and generate account
        try:
            with open(file_path, 'r') as f:
                lines = [line.strip() for line in f.readlines() if line.strip()]
            
            if not lines:
                await interaction.response.send_message(
                    f"❌ No {service_name.upper()} accounts available in stock!",
                    ephemeral=True
                )
                return
            
            # Get random account and remove it from stock
            random_account = random.choice(lines)
            lines.remove(random_account)
            
            # Write remaining accounts back to file
            with open(file_path, 'w') as f:
                for line in lines:
                    f.write(line + '\n')
            
            # Set cooldown - PREMIUM: 60 seconds (1 minute), FREE: 120 seconds (2 minutes)
            cooldown_duration = 60 if service_type == "premium" else 120
            user_cooldowns[user_id] = {
                'end_time': current_time + cooldown_duration,
                'service': f"{service_type}_{service_name}"
            }
            save_cooldowns(user_cooldowns)
            
            # Save last generation time
            if 'last_generations' not in user_settings:
                user_settings['last_generations'] = {}
            user_settings['last_generations'][f"{service_type}_{service_name.lower()}"] = current_time
            save_user_settings(user_settings)
            
            # Generate time taken (random between 1-3 seconds for realism)
            time_taken = random.uniform(1, 3)
            time_str = f"{time_taken:.2f}s"
            
            # Parse account credentials
            if ':' in random_account:
                username, password = random_account.split(':', 1)
            else:
                username = random_account
                password = "N/A"
            
            # Create the new embed format
            embed = discord.Embed(
                title=f"🤖 | Generated {service_name.upper()} Account",
                color=int(config.get('embed_color', '0x242628'), 16)
            )
            
            embed.add_field(
                name="Username",
                value=f"```{username}```",
                inline=False
            )
            
            embed.add_field(
                name="Password", 
                value=f"```{password}```",
                inline=False
            )
            
            embed.add_field(
                name="Combo",
                value=f"```{random_account}```",
                inline=False
            )
            
            embed.add_field(
                name="Generated",
                value=f"<t:{int(time.time())}:R>",
                inline=True
            )
            
            embed.add_field(
                name="Time Taken", 
                value=time_str,
                inline=True
            )
            
            embed.add_field(
                name="Plan",
                value="Premium" if service_type == "premium" else "Free",
                inline=True
            )
            
            embed.set_footer(
                text=f"Generated for {interaction.user.display_name}",
                icon_url=interaction.user.display_avatar.url
            )
            
            embed.timestamp = discord.utils.utcnow()
            
            # Create buttons view
            buttons_view = discord.ui.View()
            
            # Generate button (always the same link)
            generate_button = discord.ui.Button(
                label="Generate",
                emoji="🔥",
                style=discord.ButtonStyle.link,
                url="https://discord.com/channels/1372436123304853564/1374676350413045873"
            )
            buttons_view.add_item(generate_button)
            
            # Review button (plan-based link)
            review_link = "https://discord.com/channels/1372436123304853564/1374676361955905619" if service_type == "premium" else "https://discord.com/channels/1372436123304853564/1374676360705998899"
            review_button = discord.ui.Button(
                label="Review",
                emoji="⭐",
                style=discord.ButtonStyle.link,
                url=review_link
            )
            buttons_view.add_item(review_button)
            
            # Send based on DM settings
            if dm_enabled:
                try:
                    await interaction.user.send(embed=embed, view=buttons_view)
                    await interaction.response.send_message(
                        "✅ Account generated and sent to your DMs!",
                        ephemeral=True
                    )
                except discord.Forbidden:
                    await interaction.response.send_message(
                        "❌ Couldn't send DM. Please enable DMs from server members.",
                        ephemeral=True
                    )
            else:
                await interaction.response.send_message(embed=embed, view=buttons_view, ephemeral=True)
                
        except FileNotFoundError:
            await interaction.response.send_message(
                f"❌ {service_name.upper()} stock file not found!",
                ephemeral=True
            )
        except Exception as e:
            await interaction.response.send_message(
                "❌ An error occurred while generating the account.",
                ephemeral=True
            )
            print(f"Generation error: {e}")

class SettingsButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            label="Settings",
            emoji="🔵",
            style=discord.ButtonStyle.secondary
        )
    
    async def callback(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        
        # Get current DM generation setting
        dm_enabled = user_settings.get(user_id, {}).get('dm_generation', False)
        
        # Get ping notify status
        ping_notify = user_settings.get(user_id, {}).get('ping_notify', False)
        
        # Create settings embed
        embed = discord.Embed(
            title="Settings",
            description="Configure your account generation preferences and notifications.",
            color=int(config.get('embed_color', '0x242628'), 16)
        )
        
        # DM Generation status
        dm_status = "✅ DM Generation Enabled" if dm_enabled else "❌ DM Generation Disabled"
        # Ping Notify status  
        ping_status = "✅ Ping Notify Enabled" if ping_notify else "❌ Ping Notify Disabled"
        
        embed.add_field(
            name="Current Settings",
            value=f"{dm_status}\n{ping_status}",
            inline=False
        )
        
        embed.add_field(
            name="📨 DM Generation Info",
            value="When enabled, all generated accounts will be sent to your private messages instead of showing in the channel. This keeps your accounts private and secure.",
            inline=False
        )
        
        embed.add_field(
            name="🔔 Ping Notify Info (Premium)",
            value="When enabled, you'll receive a direct message notification when your cooldowns expire, so you know exactly when you can generate accounts again. Premium feature only.",
            inline=False
        )
        
        embed.set_footer(
            text=f"Settings for {interaction.user.display_name}",
            icon_url=interaction.user.display_avatar.url
        )
        
        embed.timestamp = discord.utils.utcnow()
        
        # Create view with enable/disable buttons
        ping_notify = user_settings.get(user_id, {}).get('ping_notify', False)
        view = SettingsView(dm_enabled, ping_notify)
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class StocksButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            label="Stocks",
            emoji="📦",
            style=discord.ButtonStyle.secondary
        )
    
    async def callback(self, interaction: discord.Interaction):
        # Create stocks embed
        embed = discord.Embed(
            title="📦 Stocks Amount",
            description="lets see how much times i can sail in sea",
            color=int(config.get('embed_color', '0x242628'), 16)
        )
        
        # Get last generation times from user settings
        last_generations = user_settings.get('last_generations', {})
        
        # Check stocks for both free and premium
        for stock_type in ['free', 'premium']:
            stock_dir = f"stocks/{stock_type}"
            if os.path.exists(stock_dir):
                for file in os.listdir(stock_dir):
                    if file.endswith('.txt'):
                        service_name = file[:-4].upper()
                        file_path = f"{stock_dir}/{file}"
                        
                        try:
                            with open(file_path, 'r') as f:
                                lines = [line.strip() for line in f.readlines() if line.strip()]
                                account_count = len(lines)
                        except:
                            account_count = 0
                        
                        # Get last generation time for this service
                        last_gen_key = f"{stock_type}_{service_name.lower()}"
                        last_gen_time = last_generations.get(last_gen_key, 0)
                        last_gen_text = f"<t:{int(last_gen_time)}:R>" if last_gen_time > 0 else "Never"
                        
                        embed.add_field(
                            name=f"{service_name} - {stock_type}",
                            value=f"`{account_count}` accounts\n> Last generated: {last_gen_text}",
                            inline=True
                        )
        
        if len(embed.fields) == 0:
            embed.add_field(
                name="No Services",
                value="No account stocks found.",
                inline=False
            )
        
        # Create refresh view with cycling emojis
        refresh_view = StocksRefreshView()
        
        await interaction.response.send_message(embed=embed, view=refresh_view, ephemeral=True)

class StocksRefreshView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.refresh_emojis = ["👶", "🧑‍🎓", "👮", "👴", "💀"]
        self.current_emoji_index = 0
        self.add_item(self.create_refresh_button())
    
    def create_refresh_button(self):
        button = discord.ui.Button(
            label="Refresh",
            emoji=self.refresh_emojis[self.current_emoji_index],
            style=discord.ButtonStyle.secondary
        )
        button.callback = self.refresh_callback
        return button
    
    async def refresh_callback(self, interaction: discord.Interaction):
        # Cycle to next emoji
        self.current_emoji_index = (self.current_emoji_index + 1) % len(self.refresh_emojis)
        
        # Create updated stocks embed
        embed = discord.Embed(
            title="📦 Stocks Amount",
            description="lets see how much times i can sail in sea",
            color=int(config.get('embed_color', '0x242628'), 16)
        )
        
        # Get last generation times from user settings
        last_generations = user_settings.get('last_generations', {})
        
        # Check stocks for both free and premium
        for stock_type in ['free', 'premium']:
            stock_dir = f"stocks/{stock_type}"
            if os.path.exists(stock_dir):
                for file in os.listdir(stock_dir):
                    if file.endswith('.txt'):
                        service_name = file[:-4].upper()
                        file_path = f"{stock_dir}/{file}"
                        
                        try:
                            with open(file_path, 'r') as f:
                                lines = [line.strip() for line in f.readlines() if line.strip()]
                                account_count = len(lines)
                        except:
                            account_count = 0
                        
                        # Get last generation time for this service
                        last_gen_key = f"{stock_type}_{service_name.lower()}"
                        last_gen_time = last_generations.get(last_gen_key, 0)
                        last_gen_text = f"<t:{int(last_gen_time)}:R>" if last_gen_time > 0 else "Never"
                        
                        embed.add_field(
                            name=f"{service_name} - {stock_type}",
                            value=f"`{account_count}` accounts\n> Last generated: {last_gen_text}",
                            inline=True
                        )
        
        if len(embed.fields) == 0:
            embed.add_field(
                name="No Services",
                value="No account stocks found.",
                inline=False
            )
        
        # Create new view with updated emoji
        new_view = StocksRefreshView()
        new_view.current_emoji_index = self.current_emoji_index
        new_view.clear_items()
        new_view.add_item(new_view.create_refresh_button())
        
        await interaction.response.edit_message(embed=embed, view=new_view)

class PremiumButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            label="Premium",
            emoji="💸",
            style=discord.ButtonStyle.link,
            url="https://discord.com/channels/1372436123304853564/1374676347967897611"
        )

class HelpButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            label="Need Help?",
            emoji="⚒️",
            style=discord.ButtonStyle.link,
            url="https://discord.com/channels/1372436123304853564/1377226195954958386"
        )

class SettingsView(discord.ui.View):
    def __init__(self, dm_enabled, ping_notify):
        super().__init__(timeout=None)
        self.dm_enabled = dm_enabled
        self.ping_notify = ping_notify
        
        # DM Generation buttons
        enable_button = discord.ui.Button(
            label="Enable DM",
            emoji="✅",
            style=discord.ButtonStyle.gray,
            disabled=dm_enabled,
            row=0
        )
        enable_button.callback = self.enable_dm
        self.add_item(enable_button)
        
        disable_button = discord.ui.Button(
            label="Disable DM", 
            emoji="❌",
            style=discord.ButtonStyle.gray,
            disabled=not dm_enabled,
            row=0
        )
        disable_button.callback = self.disable_dm
        self.add_item(disable_button)
        
        # Ping Notify buttons (Premium only)
        enable_ping_button = discord.ui.Button(
            label="Enable Ping Notify",
            emoji="🔔",
            style=discord.ButtonStyle.blurple,
            disabled=ping_notify,
            row=1
        )
        enable_ping_button.callback = self.enable_ping_notify
        self.add_item(enable_ping_button)
        
        disable_ping_button = discord.ui.Button(
            label="Disable Ping Notify",
            emoji="🔕",
            style=discord.ButtonStyle.blurple,
            disabled=not ping_notify,
            row=1
        )
        disable_ping_button.callback = self.disable_ping_notify
        self.add_item(disable_ping_button)
    
    async def enable_dm(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        
        # Update user settings
        if user_id not in user_settings:
            user_settings[user_id] = {}
        user_settings[user_id]['dm_generation'] = True
        save_user_settings(user_settings)
        
        # Get ping notify status
        ping_notify = user_settings.get(user_id, {}).get('ping_notify', False)
        
        # Update embed with new status
        embed = discord.Embed(
            title="Settings",
            description="Configure your DM generation and ping notification preferences.",
            color=int(config.get('embed_color', '0x242628'), 16)
        )
        
        # DM Generation status (now enabled)
        dm_status = "✅ DM Generation Enabled"
        # Ping Notify status  
        ping_status = "✅ Ping Notify Enabled" if ping_notify else "❌ Ping Notify Disabled"
        
        embed.add_field(
            name="Current Settings",
            value=f"{dm_status}\n{ping_status}",
            inline=False
        )
        
        embed.set_footer(
            text=f"Settings for {interaction.user.display_name}",
            icon_url=interaction.user.display_avatar.url
        )
        
        embed.timestamp = discord.utils.utcnow()
        
        # Create new view with updated button states
        new_view = SettingsView(True, ping_notify)
        
        await interaction.response.edit_message(embed=embed, view=new_view)
    
    async def disable_dm(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        
        # Update user settings
        if user_id not in user_settings:
            user_settings[user_id] = {}
        user_settings[user_id]['dm_generation'] = False
        save_user_settings(user_settings)
        
        # Get ping notify status
        ping_notify = user_settings.get(user_id, {}).get('ping_notify', False)
        
        # Update embed with new status
        embed = discord.Embed(
            title="Settings",
            description="Configure your DM generation and ping notification preferences.",
            color=int(config.get('embed_color', '0x242628'), 16)
        )
        
        # DM Generation status (now disabled)
        dm_status = "❌ DM Generation Disabled"
        # Ping Notify status  
        ping_status = "✅ Ping Notify Enabled" if ping_notify else "❌ Ping Notify Disabled"
        
        embed.add_field(
            name="Current Settings",
            value=f"{dm_status}\n{ping_status}",
            inline=False
        )
        
        embed.set_footer(
            text=f"Settings for {interaction.user.display_name}",
            icon_url=interaction.user.display_avatar.url
        )
        
        embed.timestamp = discord.utils.utcnow()
        
        # Create new view with updated button states
        new_view = SettingsView(False, ping_notify)
        
        await interaction.response.edit_message(embed=embed, view=new_view)
    
    async def enable_ping_notify(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        
        # Check if user is premium
        whitelisted = load_whitelist()
        is_premium = user_id in whitelisted
        
        if not is_premium:
            await interaction.response.send_message(
                "❌ **Ping Notify** is a premium feature. You need premium access to use this feature.",
                ephemeral=True
            )
            return
        
        # Update user settings
        if user_id not in user_settings:
            user_settings[user_id] = {}
        user_settings[user_id]['ping_notify'] = True
        save_user_settings(user_settings)
        
        # Get DM generation status
        dm_enabled = user_settings.get(user_id, {}).get('dm_generation', False)
        
        # Update embed with new status
        embed = discord.Embed(
            title="Settings",
            description="Configure your DM generation and ping notification preferences.",
            color=int(config.get('embed_color', '0x242628'), 16)
        )
        
        # DM Generation status
        dm_status = "✅ DM Generation Enabled" if dm_enabled else "❌ DM Generation Disabled"
        # Ping Notify status (now enabled)
        ping_status = "✅ Ping Notify Enabled"
        
        embed.add_field(
            name="Current Settings",
            value=f"{dm_status}\n{ping_status}",
            inline=False
        )
        
        embed.set_footer(
            text=f"Settings for {interaction.user.display_name}",
            icon_url=interaction.user.display_avatar.url
        )
        
        embed.timestamp = discord.utils.utcnow()
        
        # Create new view with updated button states
        new_view = SettingsView(dm_enabled, True)
        
        await interaction.response.edit_message(embed=embed, view=new_view)
    
    async def disable_ping_notify(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        
        # Update user settings
        if user_id not in user_settings:
            user_settings[user_id] = {}
        user_settings[user_id]['ping_notify'] = False
        save_user_settings(user_settings)
        
        # Get DM generation status
        dm_enabled = user_settings.get(user_id, {}).get('dm_generation', False)
        
        # Update embed with new status
        embed = discord.Embed(
            title="Settings",
            description="Configure your DM generation and ping notification preferences.",
            color=int(config.get('embed_color', '0x242628'), 16)
        )
        
        # DM Generation status
        dm_status = "✅ DM Generation Enabled" if dm_enabled else "❌ DM Generation Disabled"
        # Ping Notify status (now disabled)
        ping_status = "❌ Ping Notify Disabled"
        
        embed.add_field(
            name="Current Settings",
            value=f"{dm_status}\n{ping_status}",
            inline=False
        )
        
        embed.set_footer(
            text=f"Settings for {interaction.user.display_name}",
            icon_url=interaction.user.display_avatar.url
        )
        
        embed.timestamp = discord.utils.utcnow()
        
        # Create new view with updated button states
        new_view = SettingsView(dm_enabled, False)
        
        await interaction.response.edit_message(embed=embed, view=new_view)

class ServiceDropdown(discord.ui.Select):
    def __init__(self):
        # Get available services from stocks folder
        options = self.get_service_options()
        
        # If no services found, add placeholder
        if not options:
            options.append(discord.SelectOption(
                label="No services available",
                value="none",
                emoji="❌"
            ))
        
        super().__init__(
            placeholder="Choose service to generate",
            min_values=1,
            max_values=1,
            options=options
        )
    
    def get_service_options(self):
        """Dynamically load service options from stock files"""
        options = []
        
        # Add premium services first
        premium_path = "stocks/premium"
        if os.path.exists(premium_path):
            for file in os.listdir(premium_path):
                if file.endswith('.txt'):
                    service_name = file[:-4].upper()  # Remove .txt and make uppercase
                    options.append(discord.SelectOption(
                        label=f"PREMIUM - {service_name}",
                        value=f"premium_{service_name.lower()}",
                        emoji="✨"
                    ))
        
        # Add free services below premium
        free_path = "stocks/free"
        if os.path.exists(free_path):
            for file in os.listdir(free_path):
                if file.endswith('.txt'):
                    service_name = file[:-4].upper()  # Remove .txt and make uppercase
                    options.append(discord.SelectOption(
                        label=f"FREE - {service_name}",
                        value=f"free_{service_name.lower()}",
                        emoji="⭐"
                    ))
        
        return options
    
    async def callback(self, interaction: discord.Interaction):
        if self.values[0] == "none":
            await interaction.response.send_message("❌ No services are currently available.", ephemeral=True)
            return
        
        # Set the selected service in the view
        self.view.selected_service = self.values[0]
        
        # Parse the selected value for display
        service_type, service_name = self.values[0].split('_', 1)
        
        await interaction.response.send_message(
            f"✅ Selected **{service_type.upper()} - {service_name.upper()}**. Now click the Generate button to get your account!",
            ephemeral=True
        )

@bot.event
async def on_command_error(ctx, error):
    """Global error handler"""
    if isinstance(error, commands.CommandNotFound):
        return  # Ignore command not found errors
    
    print(f'Error occurred: {error}')

# Error handler for slash commands
@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: discord.app_commands.AppCommandError):
    """Error handler for slash commands"""
    if isinstance(error, discord.app_commands.CommandOnCooldown):
        if not interaction.response.is_done():
            await interaction.response.send_message(
                f"Command is on cooldown. Try again in {error.retry_after:.2f} seconds.",
                ephemeral=True
            )
    else:
        print(f'Slash command error: {error}')
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "An error occurred while processing the command.",
                ephemeral=True
            )

if __name__ == "__main__":
    # Run the bot
    try:
        bot.run(config['token'])
    except KeyError:
        print("Error: 'token' not found in bot.json")
    except discord.LoginFailure:
        print("Error: Invalid bot token")
    except Exception as e:
        print(f"Error starting bot: {e}")
