import json
import discord
from discord.ext import commands, tasks
import asyncio
import time
import os
import random
import shutil

# Load bot configuration
with open('bot.json', 'r') as f:
    config = json.load(f)

# Import and run the bot
if __name__ == "__main__":
    from bot import bot
    try:
        bot.run(config['token'])
    except KeyError:
        print("Error: 'token' not found in bot.json")
    except discord.LoginFailure:
        print("Error: Invalid bot token")
    except Exception as e:
        print(f"Error starting bot: {e}")